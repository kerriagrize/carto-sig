# Données statistiques

Les données statistiques dans le fichier Excel proviennent de la Banque mondiale. Les données peuvent être [consultées en ligne](http://databank.worldbank.org/data/reports.aspx?Code=SP.POP.TOTL&id=1ff4a498&report_name=Popular-Indicators&populartype=series&ispopular=y).

Le fichier Excel contient les données statistiques ainsi que les méta-données. Sélectionnez un ou plusieurs indicateurs de ce tableau. Assurez-vous de comprendre de quoi il s'agit exactement au niveau des indicateurs choisis.

Le fichier Excel contient les données pour plusieurs années. Pour chaque année, la liste des pays est répétée.