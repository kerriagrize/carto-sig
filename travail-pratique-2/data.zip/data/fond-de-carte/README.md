# Fond de carte pour le TP2

Ce fond de carte provient de [naturalearthdata.com](http://www.naturalearthdata.com/). Pour citer la source, voir le site Web.

Plusieurs couches sont incluses dans le dossier. Utilisez uniquement celles qui font du sens pour votre carte.

Le système de référence spatiale de l'ensemble des couches et WGS84 (système de coordonnées géographique). Choisissez une projection qui montre bien la région d'étude, sans trop de déformations.